import { motion, useScroll, useTransform } from "motion/react";
import { useRef } from "react";

export function GridBackground({ parallax = true }: { parallax?: boolean }) {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start start", "end start"],
  });
  const y = useTransform(scrollYProgress, [0, 1], ["0%", parallax ? "30%" : "0%"]);

  return (
    <div ref={ref} className="absolute inset-0 overflow-hidden pointer-events-none">
      {/* Parallax grid */}
      <motion.div className="absolute inset-0" style={{ y }}>
        <div
          className="absolute inset-0 opacity-[0.03]"
          style={{
            backgroundImage: `
              linear-gradient(rgba(108,142,255,0.5) 1px, transparent 1px),
              linear-gradient(90deg, rgba(108,142,255,0.5) 1px, transparent 1px)
            `,
            backgroundSize: "60px 60px",
          }}
        />
        {/* Dot grid overlay */}
        <div
          className="absolute inset-0 opacity-[0.04]"
          style={{
            backgroundImage: "radial-gradient(circle, rgba(108,142,255,0.7) 1px, transparent 1px)",
            backgroundSize: "30px 30px",
          }}
        />
      </motion.div>
      {/* Radial fades */}
      <div className="absolute inset-0" style={{ background: "radial-gradient(ellipse at 50% 0%, transparent 0%, #080B16 70%)" }} />
      <div className="absolute inset-0" style={{ background: "radial-gradient(ellipse at 50% 100%, transparent 0%, #080B16 70%)" }} />
    </div>
  );
}

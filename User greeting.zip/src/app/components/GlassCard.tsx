import { motion } from "motion/react";
import { ReactNode, useRef } from "react";

interface GlassCardProps {
  children: ReactNode;
  className?: string;
  hover?: boolean;
  glow?: boolean;
  tilt?: boolean;
}

export function GlassCard({ children, className = "", hover = true, glow = false, tilt = false }: GlassCardProps) {
  const ref = useRef<HTMLDivElement>(null);

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!tilt || !ref.current) return;
    const rect = ref.current.getBoundingClientRect();
    const x = (e.clientX - rect.left) / rect.width - 0.5;
    const y = (e.clientY - rect.top) / rect.height - 0.5;
    ref.current.style.transform = `perspective(800px) rotateY(${x * 8}deg) rotateX(${-y * 8}deg)`;
    const glowEl = ref.current.querySelector(".card-glow") as HTMLElement;
    if (glowEl) {
      glowEl.style.background = `radial-gradient(circle at ${(x + 0.5) * 100}% ${(y + 0.5) * 100}%, rgba(108,142,255,0.1), transparent 60%)`;
    }
  };

  const handleMouseLeave = () => {
    if (!tilt || !ref.current) return;
    ref.current.style.transform = "perspective(800px) rotateY(0deg) rotateX(0deg)";
    const glowEl = ref.current.querySelector(".card-glow") as HTMLElement;
    if (glowEl) glowEl.style.background = "transparent";
  };

  return (
    <motion.div
      ref={ref}
      whileHover={hover && !tilt ? { y: -6, transition: { type: "spring", stiffness: 400, damping: 25 } } : undefined}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      className={`group relative rounded-2xl p-[1px] will-change-transform ${className}`}
      style={{
        ...(glow ? { boxShadow: "0 0 40px rgba(108,142,255,0.08)" } : {}),
        ...(tilt ? { transition: "transform 0.15s ease-out" } : {}),
      }}
    >
      {/* Animated gradient border */}
      <div
        className="absolute inset-0 rounded-2xl opacity-40 group-hover:opacity-100 transition-opacity duration-700"
        style={{
          background: "linear-gradient(135deg, rgba(108,142,255,0.25), transparent 35%, transparent 65%, rgba(56,189,248,0.12))",
        }}
      />
      {/* Mouse-follow glow */}
      <div className="card-glow absolute inset-0 rounded-2xl transition-all duration-300 pointer-events-none" />
      {/* Card inner — glassmorphism */}
      <div
        className="relative rounded-2xl p-6 h-full overflow-hidden"
        style={{
          background: "linear-gradient(145deg, rgba(12,16,36,0.92), rgba(8,11,22,0.96))",
          backdropFilter: "blur(24px)",
          WebkitBackdropFilter: "blur(24px)",
          boxShadow: "inset 0 1px 0 0 rgba(255,255,255,0.03)",
        }}
      >
        {/* Inner subtle dot noise */}
        <div
          className="absolute inset-0 opacity-[0.018] pointer-events-none"
          style={{
            backgroundImage: "radial-gradient(circle at 1px 1px, rgba(108,142,255,0.6) 1px, transparent 0)",
            backgroundSize: "24px 24px",
          }}
        />
        <div className="relative z-10">{children}</div>
      </div>
    </motion.div>
  );
}

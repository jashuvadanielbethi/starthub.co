import { useState, useEffect } from "react";
import { Link, useLocation } from "react-router";
import { motion, AnimatePresence } from "motion/react";
import { Menu, X, ChevronRight } from "lucide-react";

export function Navbar() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();
  const isLanding = location.pathname === "/";

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const navLinks = isLanding
    ? [
        { label: "Features", href: "#founders" },
        { label: "How It Works", href: "#how-it-works" },
        { label: "Pricing", href: "#pricing" },
        { label: "Testimonials", href: "#testimonials" },
      ]
    : [];

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled ? "border-b border-white/[0.06]" : ""
      }`}
      style={{
        background: scrolled ? "rgba(8,11,22,0.92)" : "rgba(8,11,22,0.5)",
        backdropFilter: "blur(24px)",
        WebkitBackdropFilter: "blur(24px)",
      }}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-[72px]">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2.5 group">
            <div className="relative w-9 h-9 rounded-lg flex items-center justify-center overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-[#6C8EFF] to-[#38BDF8]" />
              <span className="relative text-white" style={{ fontSize: "15px", fontWeight: 800, letterSpacing: "-0.02em" }}>S</span>
            </div>
            <div className="flex items-center gap-1">
              <span className="text-white" style={{ fontSize: "18px", fontWeight: 700, letterSpacing: "-0.03em" }}>Start</span>
              <span className="text-[#6C8EFF]" style={{ fontSize: "18px", fontWeight: 700, letterSpacing: "-0.03em" }}>Hub</span>
            </div>
            <span className="hidden sm:inline-flex px-2 py-0.5 rounded bg-[#6C8EFF]/10 text-[#6C8EFF] ml-1" style={{ fontSize: "10px", fontWeight: 600, letterSpacing: "0.05em" }}>BETA</span>
          </Link>

          {/* Desktop Nav */}
          <div className="hidden lg:flex items-center gap-1">
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                className="px-4 py-2 rounded-lg text-[#8A8A9A] hover:text-white hover:bg-white/[0.04] transition-all"
                style={{ fontSize: "13px", fontWeight: 500, letterSpacing: "0.01em" }}
              >
                {link.label}
              </a>
            ))}
          </div>

          {/* Right Actions */}
          <div className="hidden lg:flex items-center gap-3">
            <Link
              to="/login"
              className="px-4 py-2 rounded-lg text-[#8A8A9A] hover:text-white transition-colors"
              style={{ fontSize: "13px", fontWeight: 500 }}
            >
              Sign in
            </Link>
            <Link
              to="/signup/founder"
              className="group relative px-5 py-2.5 rounded-lg overflow-hidden"
              style={{ fontSize: "13px", fontWeight: 600 }}
            >
              <div className="absolute inset-0 bg-gradient-to-r from-[#6C8EFF] to-[#38BDF8] transition-all group-hover:shadow-[0_0_30px_rgba(108,142,255,0.4)]" />
              <span className="relative text-white flex items-center gap-1.5">
                Get Started <ChevronRight size={14} />
              </span>
            </Link>
          </div>

          {/* Mobile Menu Button */}
          <button
            className="lg:hidden w-10 h-10 rounded-lg bg-white/[0.04] flex items-center justify-center text-white hover:bg-white/[0.08] transition-colors"
            onClick={() => setMenuOpen(!menuOpen)}
          >
            {menuOpen ? <X size={18} /> : <Menu size={18} />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {menuOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="lg:hidden overflow-hidden border-t border-white/[0.04]"
            style={{ background: "rgba(8,11,22,0.98)", backdropFilter: "blur(24px)" }}
          >
            <div className="px-4 py-6 flex flex-col gap-1">
              {navLinks.map((link) => (
                <a
                  key={link.label}
                  href={link.href}
                  className="px-4 py-3 rounded-lg text-[#8A8A9A] hover:text-white hover:bg-white/[0.04] transition-all"
                  style={{ fontSize: "14px", fontWeight: 500 }}
                  onClick={() => setMenuOpen(false)}
                >
                  {link.label}
                </a>
              ))}
              <div className="h-px bg-white/[0.06] my-3" />
              <Link to="/login" className="px-4 py-3 rounded-lg text-[#8A8A9A] hover:text-white transition-colors" style={{ fontSize: "14px", fontWeight: 500 }} onClick={() => setMenuOpen(false)}>
                Sign in
              </Link>
              <Link
                to="/signup/founder"
                className="mt-2 px-5 py-3 rounded-lg bg-gradient-to-r from-[#6C8EFF] to-[#38BDF8] text-white text-center"
                style={{ fontSize: "14px", fontWeight: 600 }}
                onClick={() => setMenuOpen(false)}
              >
                Get Started
              </Link>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
}

import { useState } from "react";
import { Link } from "react-router";
import { motion } from "motion/react";
import { Eye, EyeOff, ArrowRight, Shield, Lock, Fingerprint } from "lucide-react";
import { GridBackground } from "../components/GridBackground";

export function LoginPage() {
  const [showPassword, setShowPassword] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const inputStyle: React.CSSProperties = { fontSize: "14px", background: "rgba(10,14,26,0.8)", border: "1px solid rgba(255,255,255,0.04)", backdropFilter: "blur(8px)" };

  return (
    <div className="min-h-screen bg-[#080B16] flex items-center justify-center px-4 relative overflow-hidden">
      <GridBackground parallax={false} />

      {/* Floating orbs */}
      <motion.div className="absolute w-[500px] h-[500px] top-[10%] left-[20%] rounded-full blur-[120px] pointer-events-none" style={{ background: "rgba(108,142,255,0.08)" }} animate={{ scale: [1, 1.2, 1], opacity: [0.06, 0.12, 0.06] }} transition={{ duration: 8, repeat: Infinity }} />
      <motion.div className="absolute w-[400px] h-[400px] bottom-[10%] right-[15%] rounded-full blur-[120px] pointer-events-none" style={{ background: "rgba(56,189,248,0.06)" }} animate={{ scale: [1.1, 1, 1.1], opacity: [0.04, 0.1, 0.04] }} transition={{ duration: 10, repeat: Infinity }} />

      {/* Particles */}
      <div className="absolute inset-0 pointer-events-none">
        {Array.from({ length: 8 }).map((_, i) => (
          <motion.div key={i} className="absolute w-1 h-1 rounded-full bg-[#6C8EFF]/20" style={{ left: `${15 + Math.random() * 70}%`, top: `${15 + Math.random() * 70}%` }} animate={{ opacity: [0, 0.5, 0], scale: [0.5, 1.5, 0.5] }} transition={{ duration: 4 + Math.random() * 3, repeat: Infinity, delay: Math.random() * 3 }} />
        ))}
      </div>

      <div className="relative z-10 w-full max-w-[420px]">
        {/* Security indicators */}
        <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="flex items-center justify-center gap-5 mb-8">
          {[{ icon: Lock, label: "Encrypted" }, { icon: Shield, label: "Secure" }, { icon: Fingerprint, label: "2FA Ready" }].map((item) => (
            <motion.div key={item.label} className="flex items-center gap-1.5" whileHover={{ scale: 1.05 }}>
              <item.icon size={12} className="text-[#6C8EFF]/40" />
              <span className="text-[#444]" style={{ fontSize: "10px", fontWeight: 600, letterSpacing: "0.06em" }}>{item.label.toUpperCase()}</span>
            </motion.div>
          ))}
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 24, scale: 0.98 }} animate={{ opacity: 1, y: 0, scale: 1 }} transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}>
          <div className="relative rounded-2xl p-[1px]">
            <div className="absolute inset-0 rounded-2xl" style={{ background: "linear-gradient(180deg, rgba(108,142,255,0.15), transparent 40%, rgba(56,189,248,0.05))" }} />
            <div className="relative rounded-2xl p-8 overflow-hidden" style={{ background: "linear-gradient(180deg, rgba(12,16,36,0.97), rgba(8,11,22,0.98))", backdropFilter: "blur(24px)", boxShadow: "0 0 80px rgba(108,142,255,0.04)" }}>
              <div className="absolute inset-0 opacity-[0.015] pointer-events-none" style={{ backgroundImage: "radial-gradient(circle at 1px 1px, rgba(108,142,255,0.5) 1px, transparent 0)", backgroundSize: "20px 20px" }} />

              <div className="relative z-10">
                <div className="text-center mb-8">
                  <Link to="/" className="inline-block mb-6">
                    <motion.div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#6C8EFF] to-[#38BDF8] flex items-center justify-center mx-auto shadow-lg" style={{ boxShadow: "0 0 30px rgba(108,142,255,0.15)" }} whileHover={{ scale: 1.1, rotate: 5 }} transition={{ type: "spring", stiffness: 400 }}>
                      <span className="text-white" style={{ fontSize: "20px", fontWeight: 800 }}>S</span>
                    </motion.div>
                  </Link>
                  <motion.h1 className="text-white mb-1.5" style={{ fontSize: "24px", fontWeight: 800, letterSpacing: "-0.03em" }} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}>Welcome back</motion.h1>
                  <motion.p className="text-[#8A8A9A]" style={{ fontSize: "14px" }} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.4 }}>Sign in to your StartHub account</motion.p>
                </div>

                <form className="space-y-4" onSubmit={(e) => e.preventDefault()}>
                  <motion.div initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.35 }}>
                    <label className="block text-[#8A8A9A] mb-2" style={{ fontSize: "11px", fontWeight: 600, letterSpacing: "0.06em" }}>EMAIL</label>
                    <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@company.com" className="w-full px-4 py-3.5 rounded-xl text-white placeholder-[#333] focus:outline-none focus:ring-1 focus:ring-[#6C8EFF]/30 transition-all" style={inputStyle} />
                  </motion.div>

                  <motion.div initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.4 }}>
                    <label className="block text-[#8A8A9A] mb-2" style={{ fontSize: "11px", fontWeight: 600, letterSpacing: "0.06em" }}>PASSWORD</label>
                    <div className="relative">
                      <input type={showPassword ? "text" : "password"} value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Enter your password" className="w-full px-4 py-3.5 rounded-xl text-white placeholder-[#333] focus:outline-none focus:ring-1 focus:ring-[#6C8EFF]/30 transition-all pr-12" style={inputStyle} />
                      <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-3.5 top-1/2 -translate-y-1/2 text-[#444] hover:text-white transition-colors">
                        {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                      </button>
                    </div>
                  </motion.div>

                  <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.45 }} className="flex items-center justify-between">
                    <label className="flex items-center gap-2.5 cursor-pointer group">
                      <div className="w-4 h-4 rounded border border-white/[0.08] bg-[#0A0E1A] group-hover:border-[#6C8EFF]/30 transition-colors" />
                      <span className="text-[#8A8A9A]" style={{ fontSize: "13px" }}>Remember me</span>
                    </label>
                    <a href="#" className="text-[#6C8EFF]/70 hover:text-[#6C8EFF] transition-colors" style={{ fontSize: "13px", fontWeight: 500 }}>Forgot password?</a>
                  </motion.div>

                  <motion.button type="submit" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }} whileHover={{ scale: 1.01 }} whileTap={{ scale: 0.98 }} className="group relative w-full py-3.5 rounded-xl overflow-hidden mt-2" style={{ fontSize: "14px", fontWeight: 600 }}>
                    <div className="absolute inset-0 bg-gradient-to-r from-[#6C8EFF] to-[#38BDF8] transition-all group-hover:shadow-[0_0_40px_rgba(108,142,255,0.35)]" />
                    <motion.div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent" animate={{ x: ["-100%", "100%"] }} transition={{ duration: 2, repeat: Infinity, repeatDelay: 4 }} />
                    <span className="relative text-white flex items-center justify-center gap-2">Sign In <ArrowRight size={16} /></span>
                  </motion.button>
                </form>

                <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.6 }} className="mt-8 pt-6 border-t border-white/[0.04] text-center">
                  <p className="text-[#8A8A9A]" style={{ fontSize: "13px" }}>
                    Don't have an account?{" "}
                    <Link to="/signup/founder" className="text-[#6C8EFF] hover:underline" style={{ fontWeight: 600 }}>Create account</Link>
                  </p>
                </motion.div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}

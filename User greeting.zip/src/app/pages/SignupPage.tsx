import { useState } from "react";
import { Link, useParams } from "react-router";
import { motion } from "motion/react";
import { Eye, EyeOff, ArrowRight, Briefcase, TrendingUp, Shield } from "lucide-react";
import { GridBackground } from "../components/GridBackground";

export function SignupPage() {
  const { role } = useParams<{ role: string }>();
  const isFounder = role === "founder";
  const [showPassword, setShowPassword] = useState(false);

  const inputCls = "w-full px-4 py-3.5 rounded-xl text-white placeholder-[#333] focus:outline-none focus:ring-1 focus:ring-[#6C8EFF]/30 transition-all";
  const inputStyle: React.CSSProperties = { fontSize: "14px", background: "rgba(10,14,26,0.8)", border: "1px solid rgba(255,255,255,0.04)", backdropFilter: "blur(8px)" };

  return (
    <div className="min-h-screen bg-[#080B16] flex items-center justify-center px-4 pt-24 pb-12 relative overflow-hidden">
      <GridBackground parallax={false} />
      <motion.div className="absolute w-[500px] h-[500px] top-[5%] left-[10%] rounded-full blur-[120px] pointer-events-none" style={{ background: "rgba(108,142,255,0.08)" }} animate={{ scale: [1, 1.2, 1], opacity: [0.04, 0.1, 0.04] }} transition={{ duration: 8, repeat: Infinity }} />
      <motion.div className="absolute w-[400px] h-[400px] bottom-[5%] right-[10%] rounded-full blur-[120px] pointer-events-none" style={{ background: "rgba(56,189,248,0.06)" }} animate={{ scale: [1.1, 1, 1.1], opacity: [0.03, 0.08, 0.03] }} transition={{ duration: 10, repeat: Infinity }} />

      {/* Particles */}
      <div className="absolute inset-0 pointer-events-none">
        {Array.from({ length: 10 }).map((_, i) => (
          <motion.div key={i} className="absolute w-1 h-1 rounded-full bg-[#6C8EFF]/20" style={{ left: `${10 + Math.random() * 80}%`, top: `${10 + Math.random() * 80}%` }} animate={{ opacity: [0, 0.4, 0], scale: [0.5, 1.5, 0.5] }} transition={{ duration: 4 + Math.random() * 3, repeat: Infinity, delay: Math.random() * 3 }} />
        ))}
      </div>

      <motion.div initial={{ opacity: 0, y: 24, scale: 0.98 }} animate={{ opacity: 1, y: 0, scale: 1 }} transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }} className="relative z-10 w-full max-w-[440px]">
        <div className="relative rounded-2xl p-[1px]">
          <div className="absolute inset-0 rounded-2xl" style={{ background: "linear-gradient(180deg, rgba(108,142,255,0.15), transparent 40%, rgba(56,189,248,0.05))" }} />
          <div className="relative rounded-2xl p-8 overflow-hidden" style={{ background: "linear-gradient(180deg, rgba(12,16,36,0.97), rgba(8,11,22,0.98))", backdropFilter: "blur(24px)", boxShadow: "0 0 80px rgba(108,142,255,0.04)" }}>
            <div className="absolute inset-0 opacity-[0.015] pointer-events-none" style={{ backgroundImage: "radial-gradient(circle at 1px 1px, rgba(108,142,255,0.5) 1px, transparent 0)", backgroundSize: "20px 20px" }} />

            <div className="relative z-10">
              <div className="text-center mb-8">
                <Link to="/" className="inline-block mb-6">
                  <motion.div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#6C8EFF] to-[#38BDF8] flex items-center justify-center mx-auto" style={{ boxShadow: "0 0 30px rgba(108,142,255,0.15)" }} whileHover={{ scale: 1.1, rotate: 5 }} transition={{ type: "spring", stiffness: 400 }}>
                    <span className="text-white" style={{ fontSize: "20px", fontWeight: 800 }}>S</span>
                  </motion.div>
                </Link>

                {/* Role toggle */}
                <div className="inline-flex rounded-xl border border-white/[0.06] p-1 mb-6" style={{ background: "rgba(10,14,26,0.8)", backdropFilter: "blur(12px)" }}>
                  {(["founder", "investor"] as const).map((tab) => (
                    <Link key={tab} to={`/signup/${tab}`} className={`px-5 py-2.5 rounded-lg transition-all flex items-center gap-2 relative ${(tab === "founder" ? isFounder : !isFounder) ? "text-white" : "text-[#8A8A9A] hover:text-white"}`} style={{ fontSize: "13px", fontWeight: 600 }}>
                      {(tab === "founder" ? isFounder : !isFounder) && <motion.div layoutId="signup-tab-bg" className="absolute inset-0 rounded-lg bg-gradient-to-r from-[#6C8EFF] to-[#38BDF8]" transition={{ type: "spring", stiffness: 500, damping: 35 }} />}
                      <span className="relative flex items-center gap-2">{tab === "founder" ? <Briefcase size={14} /> : <TrendingUp size={14} />}{tab === "founder" ? "Founder" : "Investor"}</span>
                    </Link>
                  ))}
                </div>

                <motion.h1 key={role} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="text-white mb-1.5" style={{ fontSize: "24px", fontWeight: 800, letterSpacing: "-0.03em" }}>{isFounder ? "Launch Your Startup" : "Start Investing"}</motion.h1>
                <motion.p key={`d-${role}`} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.1 }} className="text-[#8A8A9A]" style={{ fontSize: "14px" }}>{isFounder ? "Create an encrypted startup profile" : "Join as a verified investor"}</motion.p>
              </div>

              <form className="space-y-4" onSubmit={(e) => e.preventDefault()}>
                <motion.div className="grid grid-cols-2 gap-3" initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.15 }}>
                  <div><label className="block text-[#8A8A9A] mb-2" style={{ fontSize: "11px", fontWeight: 600, letterSpacing: "0.06em" }}>FIRST NAME</label><input type="text" placeholder="John" className={inputCls} style={inputStyle} /></div>
                  <div><label className="block text-[#8A8A9A] mb-2" style={{ fontSize: "11px", fontWeight: 600, letterSpacing: "0.06em" }}>LAST NAME</label><input type="text" placeholder="Doe" className={inputCls} style={inputStyle} /></div>
                </motion.div>
                <motion.div initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.2 }}>
                  <label className="block text-[#8A8A9A] mb-2" style={{ fontSize: "11px", fontWeight: 600, letterSpacing: "0.06em" }}>EMAIL</label>
                  <input type="email" placeholder="you@company.com" className={inputCls} style={inputStyle} />
                </motion.div>
                <motion.div initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.25 }}>
                  <label className="block text-[#8A8A9A] mb-2" style={{ fontSize: "11px", fontWeight: 600, letterSpacing: "0.06em" }}>CITY</label>
                  <input type="text" placeholder="San Francisco" className={inputCls} style={inputStyle} />
                </motion.div>
                <motion.div key={`f-${role}`} initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.3 }}>
                  {!isFounder ? (
                    <div><label className="block text-[#8A8A9A] mb-2" style={{ fontSize: "11px", fontWeight: 600, letterSpacing: "0.06em" }}>INVESTMENT RANGE</label><select className={`${inputCls} appearance-none`} style={inputStyle} defaultValue=""><option value="" disabled>Select range</option><option>$500 - $5,000</option><option>$5,000 - $25,000</option><option>$25,000 - $100,000</option><option>$100,000+</option></select></div>
                  ) : (
                    <div><label className="block text-[#8A8A9A] mb-2" style={{ fontSize: "11px", fontWeight: 600, letterSpacing: "0.06em" }}>INDUSTRY</label><select className={`${inputCls} appearance-none`} style={inputStyle} defaultValue=""><option value="" disabled>Select industry</option><option>FinTech</option><option>HealthTech</option><option>EdTech</option><option>SaaS</option><option>AI/ML</option><option>E-Commerce</option><option>Other</option></select></div>
                  )}
                </motion.div>
                <motion.div initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.35 }}>
                  <label className="block text-[#8A8A9A] mb-2" style={{ fontSize: "11px", fontWeight: 600, letterSpacing: "0.06em" }}>PASSWORD</label>
                  <div className="relative">
                    <input type={showPassword ? "text" : "password"} placeholder="Min 8 characters" className={`${inputCls} pr-12`} style={inputStyle} />
                    <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-3.5 top-1/2 -translate-y-1/2 text-[#444] hover:text-white transition-colors">{showPassword ? <EyeOff size={16} /> : <Eye size={16} />}</button>
                  </div>
                </motion.div>
                <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.4 }} className="flex items-start gap-2.5 pt-1">
                  <Shield size={14} className="text-[#6C8EFF]/30 mt-0.5 shrink-0" />
                  <p className="text-[#444]" style={{ fontSize: "12px", lineHeight: 1.5 }}>By creating an account, you agree to our Terms & Privacy Policy. Data is encrypted end-to-end.</p>
                </motion.div>
                <motion.button type="submit" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.45 }} whileHover={{ scale: 1.01 }} whileTap={{ scale: 0.98 }} className="group relative w-full py-3.5 rounded-xl overflow-hidden" style={{ fontSize: "14px", fontWeight: 600 }}>
                  <div className="absolute inset-0 bg-gradient-to-r from-[#6C8EFF] to-[#38BDF8] transition-all group-hover:shadow-[0_0_40px_rgba(108,142,255,0.35)]" />
                  <motion.div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent" animate={{ x: ["-100%", "100%"] }} transition={{ duration: 2, repeat: Infinity, repeatDelay: 4 }} />
                  <span className="relative text-white flex items-center justify-center gap-2">Create Account <ArrowRight size={16} /></span>
                </motion.button>
              </form>

              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.55 }} className="mt-6 pt-6 border-t border-white/[0.04] text-center">
                <p className="text-[#8A8A9A]" style={{ fontSize: "13px" }}>Already have an account?{" "}<Link to="/login" className="text-[#6C8EFF] hover:underline" style={{ fontWeight: 600 }}>Sign in</Link></p>
              </motion.div>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
